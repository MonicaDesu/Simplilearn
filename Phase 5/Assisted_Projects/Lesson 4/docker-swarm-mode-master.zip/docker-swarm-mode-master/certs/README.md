Certificates in this directory are specifically generated to test the solution:
* On a local machine - `xip.io.pem`
* In Docker4AWS - `ci.pem` in London region _(eu-west-2)_

See this tutorial, [Configuring SSL Certificates](http://proxy.dockerflow.com/certs/), on how to create certificates and then how to use them with the proxy service as secrets
